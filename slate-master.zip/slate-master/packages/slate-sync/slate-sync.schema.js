const commonPaths = require('@shopify/slate-config/common/paths.schema');

module.exports = {
  ...commonPaths,
};
