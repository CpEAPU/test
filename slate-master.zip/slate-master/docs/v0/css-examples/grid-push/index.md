---
layout: demo
---

<div class="grid-example">
  <div class="grid">
    <div class="grid__item medium-up--one-quarter medium-up--push-one-quarter">
      <p class="grid-demo">1</p>
    </div>
    <div class="grid__item medium-up--one-quarter medium-up--push-one-half">
      <p class="grid-demo">1.1</p>
    </div>
  </div>
</div>
