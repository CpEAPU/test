# @shopify/slate-error

Slate's global error class.
