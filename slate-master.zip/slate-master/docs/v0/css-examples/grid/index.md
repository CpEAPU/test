---
layout: demo
---

<div class="grid-example">
  <div class="grid">
    <div class="grid__item">
      <p class="grid-demo">1</p>
    </div>
    <div class="grid__item">
      <div class="grid">
        <div class="grid__item medium-up--one-half">
          <p class="grid-demo">2.1</p>
        </div>
        <div class="grid__item medium-up--one-quarter">
          <p class="grid-demo">2.2</p>
        </div>
        <div class="grid__item medium-up--one-quarter">
          <p class="grid-demo">2.3</p>
        </div>
        <div class="grid__item medium-up--one-third">
          <p class="grid-demo">2.4</p>
        </div>
        <div class="grid__item medium-up--one-third small--one-half">
          <p class="grid-demo">2.5</p>
        </div>
        <div class="grid__item medium-up--one-third small--one-half">
          <p class="grid-demo">2.6</p>
        </div>
      </div>
    </div>
    <div class="grid__item">
      <div class="grid">
        <div class="grid__item medium-up--one-twelfth one-sixth small--one-third">
          <p class="grid-demo">3.1</p>
        </div>
        <div class="grid__item medium-up--one-twelfth one-sixth small--one-third">
          <p class="grid-demo">3.2</p>
        </div>
        <div class="grid__item medium-up--one-twelfth one-sixth small--one-third">
          <p class="grid-demo">3.3</p>
        </div>
        <div class="grid__item medium-up--one-twelfth one-sixth small--one-third">
          <p class="grid-demo">3.4</p>
        </div>
        <div class="grid__item medium-up--one-twelfth one-sixth small--one-third">
          <p class="grid-demo">3.5</p>
        </div>
        <div class="grid__item medium-up--one-twelfth one-sixth small--one-third">
          <p class="grid-demo">3.6</p>
        </div>
        <div class="grid__item medium-up--one-half one-whole">
          <p class="grid-demo" >3.7</p>
        </div>
      </div>
    </div>
  </div>
</div>
