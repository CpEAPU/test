import '../fixtures/style.css';
