exports = module.exports = require("../../node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.id, ".heading {\n  color: var(--headings_color);\n  background-color: '#FF00FF';\n  letter-spacing: var(--letter_spacing);\n}\n\n.title {\n  color: var(--headings_color);\n  font-weight: var(--font-body-bold-weight);\n}\n\nbody {\n  background-color: var(--body_color);\n}", ""]);

// exports
