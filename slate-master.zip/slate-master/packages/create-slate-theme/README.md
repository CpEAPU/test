[![npm version](https://badge.fury.io/js/create-slate-theme.svg)](https://badge.fury.io/js/create-slate-theme)

# create-slate-theme

The `create-slate-theme` package enables users to create a new Slate project with a single command.

For more information, visit [the documentation website](https://shopify.github.io/slate/docs/create-slate-theme).
