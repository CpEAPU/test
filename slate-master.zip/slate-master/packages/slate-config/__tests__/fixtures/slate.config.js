module.exports = {
  'some.key': 'override-value',
  'other.item': 'other-value',
};
